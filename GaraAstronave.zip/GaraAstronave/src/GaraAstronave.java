import java.util.Scanner;

public class GaraAstronave {
    double distanza;

    public void attendiFineGara(Thread... threads) {
        for (Thread t : threads) {
            try { t.join(); }
            catch (InterruptedException e) {}
        }
    }

    public void avviaGara(int nPartecipanti, double distanza) {
        Giudice giudice = new Giudice(distanza);
        Thread[] threads = new Thread[nPartecipanti];

        for (int i = 0; i < nPartecipanti; i++)
            threads[i] = new Thread(new Astronave(i + 1, giudice));

        System.out.println("La gara è iniziata!");

        for (Thread t : threads) t.start();
        attendiFineGara(threads);

        System.out.println("Classifica finale:");
        giudice.mostraPodio();
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Numero partecipanti: ");
        int n = sc.nextInt();

        System.out.print("Lunghezza del percorso: ");
        double d = sc.nextDouble();

        new GaraAstronave().avviaGara(n, d);
    }
}