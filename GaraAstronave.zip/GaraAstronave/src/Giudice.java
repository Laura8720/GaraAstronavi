import java.util.ArrayList;
import java.util.List;

public class Giudice {
    List<Integer> podio = new ArrayList<>();
    int vincitore = -1;
    double distanzaTraguardo;
    boolean garaFinita = false;

    public Giudice(double distanzaTraguardo) {
        this.distanzaTraguardo = distanzaTraguardo;
    }

    public synchronized void aggiungiVincitore(int id) {
        if (!podio.contains(id)) {
            podio.add(id);
            if (vincitore == -1) vincitore = id;
        }
    }

    public synchronized void mostraPodio() {
        for (int i = 0; i < podio.size(); i++) {
            System.out.println((i+1) + "° posto: " + podio.get(i));
        }
    }

    public synchronized boolean verifica(double percorso, int id) {
        if (percorso >= distanzaTraguardo) {
            aggiungiVincitore(id);
            return true;
        }
        return false;
    }
}