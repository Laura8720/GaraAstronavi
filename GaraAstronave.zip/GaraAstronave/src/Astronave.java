public class Astronave implements Runnable {
    int nome;
    double velocità;
    double distanzaPercorsa = 0;
    Giudice giudice;

    public Astronave(int nome, Giudice giudice) {
        this.nome = nome;
        this.giudice = giudice;
        this.velocità = 50 + (int)(Math.random() * 251);
    }

    @Override
    public void run() {
        System.out.println("Partecipante " + nome + " velocità: " + velocità);

        while (true) {
            distanzaPercorsa += velocità;
            System.out.println("Partecipante " + nome + " ha percorso: " + distanzaPercorsa);

            if (giudice.verifica(distanzaPercorsa, nome)) break;

            try { Thread.sleep(1000); }
            catch (InterruptedException e) {}
        }
    }
}